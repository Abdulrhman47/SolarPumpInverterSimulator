\
    package com.solarpump.simulator;

    import android.app.Activity;
    import android.graphics.Color;
    import android.os.Bundle;
    import android.view.View;
    import android.view.Window;
    import android.view.WindowInsets;
    import android.view.WindowInsetsController;
    import android.webkit.WebChromeClient;
    import android.webkit.WebResourceRequest;
    import android.webkit.WebSettings;
    import android.webkit.WebView;
    import android.webkit.WebViewClient;

    public class MainActivity extends Activity {

        private WebView webView;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);

            Window window = getWindow();
            window.setStatusBarColor(Color.rgb(6, 16, 26));
            window.setNavigationBarColor(Color.rgb(6, 16, 26));

            webView = new WebView(this);
            webView.setBackgroundColor(Color.rgb(6, 16, 26));

            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setAllowFileAccess(true);
            settings.setAllowContentAccess(false);
            settings.setBuiltInZoomControls(false);
            settings.setDisplayZoomControls(false);
            settings.setLoadWithOverviewMode(true);
            settings.setUseWideViewPort(true);
            settings.setMediaPlaybackRequiresUserGesture(true);

            webView.setWebChromeClient(new WebChromeClient());
            webView.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    String url = request.getUrl().toString();
                    return !url.startsWith("file:///android_asset/");
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    return !url.startsWith("file:///android_asset/");
                }
            });

            setContentView(webView);

            if (savedInstanceState == null) {
                webView.loadUrl("file:///android_asset/index.html");
            } else {
                webView.restoreState(savedInstanceState);
            }
        }

        @Override
        protected void onSaveInstanceState(Bundle outState) {
            webView.saveState(outState);
            super.onSaveInstanceState(outState);
        }

        @Override
        public void onBackPressed() {
            if (webView != null && webView.canGoBack()) {
                webView.goBack();
            } else {
                super.onBackPressed();
            }
        }

        @Override
        protected void onDestroy() {
            if (webView != null) {
                webView.loadUrl("about:blank");
                webView.stopLoading();
                webView.setWebChromeClient(null);
                webView.setWebViewClient(null);
                webView.destroy();
                webView = null;
            }
            super.onDestroy();
        }
    }
