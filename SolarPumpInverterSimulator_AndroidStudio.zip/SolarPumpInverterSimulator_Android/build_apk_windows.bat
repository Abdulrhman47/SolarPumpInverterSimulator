@echo off
echo Building Solar Pump Inverter Simulator...
gradle :app:assembleDebug
if %errorlevel% neq 0 (
  echo.
  echo Build failed. Make sure JDK 17, Android SDK 37 and Gradle 9.5.0 are installed.
  pause
  exit /b %errorlevel%
)
echo.
echo APK: app\build\outputs\apk\debug\app-debug.apk
pause
