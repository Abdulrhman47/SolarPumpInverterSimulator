# Solar Pump Inverter Simulator (Android)

Offline Android WebView application that bundles the interactive INVT-style solar pump simulator.
See `README_AR.md` for Arabic build instructions.

Build output:
`app/build/outputs/apk/debug/app-debug.apk`
